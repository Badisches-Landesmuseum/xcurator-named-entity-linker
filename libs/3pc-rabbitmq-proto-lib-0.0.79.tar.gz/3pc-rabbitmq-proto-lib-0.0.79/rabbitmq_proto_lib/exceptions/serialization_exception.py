class SerialisationException(Exception):
    """Base class for other exceptions"""
    pass
