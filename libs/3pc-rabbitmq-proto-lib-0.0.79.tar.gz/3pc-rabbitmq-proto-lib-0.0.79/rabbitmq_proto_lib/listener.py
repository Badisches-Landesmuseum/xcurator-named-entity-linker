import asyncio
import logging
from abc import abstractmethod, ABCMeta

from aio_pika import IncomingMessage

from rabbitmq_proto_lib.exceptions.serialization_exception import SerialisationException
from rabbitmq_proto_lib.models.queue import RabbitQueue
from rabbitmq_proto_lib.publisher import RabbitPublisher


class RabbitListener(RabbitQueue, RabbitPublisher, metaclass=ABCMeta):
    """ Abstraction of the RabbitMQ Consumer"""

    async def _on_message_raw(self, message: IncomingMessage):
        async with message.process(ignore_processed=True):

            try:
                message_converter = await self._get_message_converter_by_content_type(message.content_type)
                body = await message_converter.decode_body(message)
                result = await self.on_message(body, message)
                if result and message.reply_to:
                    reply_message = await self._create_proto_message(result)
                    reply_message.correlation_id = message.correlation_id
                    await self.send(message.reply_to, reply_message, "")
            except (SerialisationException, asyncio.TimeoutError):
                await message.reject()
                return
            except Exception as err:
                logging.error(str(err))
                await message.reject(requeue=True)
                return

            await message.ack()

    @abstractmethod
    async def on_message(self, body, message: IncomingMessage):
        raise NotImplemented("You forgot to implement 'on_message' method. For the arriving messages!")
