import logging

import google.protobuf.internal.decoder as decoder
import google.protobuf.internal.encoder as encoder
from aio_pika import IncomingMessage
from betterproto import Message

from rabbitmq_proto_lib.converter.message_converter import RabbitMessageConverter
from rabbitmq_proto_lib.dreipc_message_header import DreiPCMessageHeader
from rabbitmq_proto_lib.exceptions.serialization_exception import SerialisationException


class ProtoMessageConverter(RabbitMessageConverter[Message]):

    _known_types = {}
    content_type = "application/protobuf"

    def __init__(self):
        proto_types = self._find_proto_types()
        for body_type in proto_types:
            self.register_type(body_type)

    def register_type(self, body_type: Message):
        class_name = body_type.__name__.upper()
        logging.debug("Register Proto type: " + class_name)
        self._known_types[class_name] = body_type

    def set_header(self, message: IncomingMessage) -> IncomingMessage:
        message.content_type = self.content_type

    async def encode_body(self, body: Message) -> bytes:
        return self.write_delimited(body)

    async def decode_body(self, message: IncomingMessage) -> Message:
        if message.content_type != self.content_type:
            raise SerialisationException("Unknown Content Type of Message! Given Type; " + message.content_type)
        message_type = message.headers[DreiPCMessageHeader.MESSAGE_TYPE]
        if not message_type:
            raise SerialisationException("No Message body type given, can't decode message!")
        if message_type not in self._known_types:
            raise SerialisationException("Unknown Type to decode. Given Type: " + message_type)
        body_type = self._known_types[message_type]
        return self.get_body(message.body, body_type)

    def get_body(self, body: bytes, body_type: Message):
        return self.read_delimited(body, body_type)

    def _get_type(self, body_type_name: str) -> Message:
        return self._known_types[body_type_name]

    @staticmethod
    def write_delimited(proto_data: Message) -> bytes:
        """ Serialize Proto data classes into a common binary format.
        :param proto_data: proto data instance to send inside the body of a message.
        :return: proto_data serialized in bytes
        """
        body = bytes(proto_data)
        return encoder._VarintBytes(len(body)) + body

    @staticmethod
    def read_delimited(delimited_bytes, proto_data_type: Message) -> Message:
        """ Deserialize bytes array to Proto data instance.
        :param delimited_bytes: delimited proto bytes array for serialisation.
        :param proto_data_type: proto target class type of the serialization.
        :return: serialized instance of the proto object.
        """
        message = proto_data_type
        next_pos, pos = decoder._DecodeVarint32(delimited_bytes, 0)
        return message.FromString(delimited_bytes[pos:pos + next_pos])

    def _find_proto_types(self) -> set:
        subclasses = set()
        work = [Message]
        while work:
            parent = work.pop()
            for child in parent.__subclasses__():
                if child not in subclasses and not child.__name__.startswith("_"):
                    subclasses.add(child)
                    work.append(child)
        return subclasses
