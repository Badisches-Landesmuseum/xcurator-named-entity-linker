from typing import Dict, List


class RabbitQueue:
    """RabbitMQ Queue representation

    Attributes:
        name     Queue name for consuming Messages
        exchange_name   Consumer Exchange name, where the queue should  be bounded to.
        passive   Boolean Flag if the Queue should be
    """
    name: str = None
    _arguments: Dict[str, str] = {
        "x-queue-mode": "lazy"
    }
    exchange_name: str = ""
    passive: bool = False
    durable: bool = True
    exclusive: bool = False
    auto_delete: bool = False
    prefetch_count: int = 250
    dead_letter_exchange: str = None
    routing_keys: List[str] = []

    @property
    def arguments(self):
        if self.dead_letter_exchange:
            self._arguments["x-dead-letter-exchange"] = self.dead_letter_exchange
        return self._arguments
