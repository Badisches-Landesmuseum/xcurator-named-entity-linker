from enum import Enum


class ExchangeType(Enum):
    TOPIC = 'topic'
    DIRECT = 'direct'
    FANOUT = 'fanout'


class RabbitExchange:
    """
    :param str name: The exchange name; if empty string, the broker will
    create a unique queue name
    :param bool durable: Survive reboots of the broker
    :param ExchangeType exchange_type: Type of the Exchange. Default: Topic
    """

    def __init__(self, name: str = "", exchange_type: ExchangeType = ExchangeType.TOPIC, is_dlx=False, durable=True,
                 declare=False):
        self.name = name
        self.type = exchange_type
        self.durable = durable
        self.declare = declare
        self.is_dlx = is_dlx
