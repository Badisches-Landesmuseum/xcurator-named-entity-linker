

class DreiPCMessageHeader:
    '''
    Common used Header (-Keys) inside RabbitMQ Messages
    '''

    __PREFIX = "DREIPC_"
    REPLY_TO_ERROR = __PREFIX + "REPLY_TO_ERROR"  # not used -> define an dead letter exchange
    MESSAGE_TYPE = __PREFIX + "MESSAGE_TYPE"  # refactor -> official message property: message.type
    TRACE_ID = __PREFIX + "TRACE_ID"  # refactor -> official message property: message.correlationId
    REPLY_EXCHANGE = __PREFIX + "REPLY_EXCHANGE"  # not used -> commonly the default exchange is used
