import asyncio
import logging
from multiprocessing.dummy import Process

import aio_pika
import aiormq
from aio_pika.pool import Pool
from retrying import retry

from rabbitmq_proto_lib.converter.proto_converter import ProtoMessageConverter
from rabbitmq_proto_lib.converter.string_converter import StringMessageConverter
from rabbitmq_proto_lib.listener import RabbitListener
from rabbitmq_proto_lib.publisher import RabbitPublisher


def _retry_on_connection_error(exception):
    should_retry = isinstance(exception, ConnectionError) or isinstance(exception,
                                                                        aiormq.exceptions.IncompatibleProtocolError)
    if should_retry:
        logging.warning("Can't connect to RabbitMQ. Initiate retry.")
    return should_retry


class RabbitManager(Process):
    """Manager for the RabbitMQ Broker connection and the handling of Application Listeners, Publishers,
    RabbitMQ Queues, Exchanges, Bindings and Message Converters"""

    _consumer = []
    _publisher = []
    _message_converter = {}
    _loop = asyncio.new_event_loop()
    _run_task = True

    def __init__(self, rabbit_config: dict, app_name: str):
        super().__init__(target=self._run)
        if not app_name:
            raise ValueError("No Application name given. Please tell me the name of your application.")

        self.app_name = app_name.lower()
        self.daemon = True
        self.amqp_url = f"amqp://{rabbit_config['username']}:{rabbit_config['password']}@" \
                        f"{rabbit_config['host']}:{rabbit_config['port']}{rabbit_config['vhost']}"

        self._init_message_converter()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._start_consume())

    def _init_message_converter(self):
        string_converter = StringMessageConverter()
        self._message_converter[string_converter.content_type] = string_converter
        proto_converter = ProtoMessageConverter()
        self._message_converter[proto_converter.content_type] = proto_converter

    def connect(self):
        """Connect to the RabbitMQ Broker and setup Listeners, Publishers and Message Converter"""
        self.start()

    @retry(retry_on_exception=_retry_on_connection_error, wait_random_min=1000, wait_random_max=2000)
    def _run(self):
        """Start Process-routine for the RabbitManager."""
        # self._loop.run_until_complete(self._start_consume())
        while (self._run_task):
            pass
        # try:
        #     self._loop.run_forever()
        # finally:
        self._loop.run_until_complete(self.disconnect())

    async def _start_consume(self):
        """Connect to RabbitMQ and setup all Publishers and Listeners."""
        self._connection_pool = Pool(self._get_connection, max_size=2, loop=self._loop)
        self._channel_pool = Pool(self._get_channel, max_size=10, loop=self._loop)

        self._publish_channel = await self._get_channel()

    async def _register_queues(self, listener: RabbitListener):
        """Create a Queue for each RabbitListener including Settings and Bindings."""
        channel = await self._get_channel()
        await channel.set_qos(listener.prefetch_count)

        queue = await channel.declare_queue(
            name=listener.name, durable=listener.durable,
            exclusive=listener.exclusive, passive=listener.passive,
            auto_delete=listener.auto_delete, arguments=listener.arguments
        )

        for routing_key in listener.routing_keys:
            await queue.bind(exchange=listener.exchange_name, routing_key=routing_key)
        await queue.consume(listener._on_message_raw)

    def register(self, rabbit_component: RabbitPublisher):
        rabbit_component.loop(self._loop)
        rabbit_component.add_message_converters(self._message_converter)
        self._loop.run_until_complete(rabbit_component.channel(self._publish_channel))

        if isinstance(rabbit_component, RabbitListener):
            self._loop.run_until_complete(self._register_queues(rabbit_component))

    def add_listener(self, listener: RabbitListener):
        """Adding a new RabbitListener (Queue) for receiving and sending Messages."""
        self._consumer.append(listener)
        listener.loop(self._loop)
        listener.add_message_converters(self._message_converter)
        self._loop.run_until_complete(self._register_queues(listener))

    def add_publisher(self, publisher: RabbitPublisher):
        """Adding a new RabbitPublisher for sending Messages"""
        self._publisher.append(publisher)
        publisher.loop(self._loop)
        publisher.add_message_converters(self._message_converter)
        self._loop.run_until_complete(publisher.channel(self._publish_channel))

    async def _get_channel(self) -> aio_pika.Channel:
        """Create a new Rabbit Channel."""
        async with self._connection_pool.acquire() as connection:
            return await connection.channel(publisher_confirms=True)

    async def _get_connection(self) -> aio_pika.Channel:
        """Create a new Rabbit Connection."""
        return await aio_pika.connect_robust(self.amqp_url)

    async def disconnect(self):
        """Close the Connection and terminate the RabbitMQ Process."""
        if self._connection_pool:
            while not self._connection_pool._Pool__items.empty():
                connection = self._connection_pool._Pool__items.get_nowait()
                await connection.close()

    def stop(self):
        self._loop.stop()
        self._run_task = False
        # thread_id = self.ident
        # res = ctypes.pythonapi.PyThreadState_SetAsyncExc(self.ident,
        #                                                  ctypes.py_object(SystemExit))
        # if res > 1:
        #     ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id, 0)
        #     print('Exception raise failure')
        #
        # if self._pid:
        #   os.kill(self._pid, signal.SIGTERM)
