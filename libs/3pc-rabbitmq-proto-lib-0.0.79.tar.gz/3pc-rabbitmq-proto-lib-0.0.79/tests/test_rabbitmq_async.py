import asyncio
from unittest import TestCase

import nest_asyncio

from manager import RabbitManager
from proto.asset.objectdetection import ObjectProto, PointProto
from util.consumer import TestConsumer
from util.consumer_proto import TestProtoConsumer
from util.publisher import TestPublisher
from util.publisher_proto import TestProtoPublisher
from util.rpc_client import TestRPC


class TestRabbitMQAsync(TestCase):
    RABBIT_CONFIG = {'username': 'dreipc',
                     'password': 'password',
                     'host': 'localhost',
                     'port': 5672,
                     'vhost': '/'}

    RABBIT_LISTENER = TestConsumer()

    _proto_object = ObjectProto(label="test-label",
                                confidence=0.93,
                                top_left=PointProto(x=1, y=100),
                                bottom_right=PointProto(x=450, y=360))

    def setUp(self) -> None:
        self.rabbitmq = RabbitManager(TestRabbitMQAsync.RABBIT_CONFIG, app_name="test")
        nest_asyncio.apply(self.rabbitmq._loop)

    def test_init(self):
        self.assertIsNotNone(self.rabbitmq)

    def test_connect(self):
        publisher = TestPublisher()
        self.rabbitmq.register(publisher)

        self.rabbitmq.register(TestConsumer(1))
        self.rabbitmq.register(TestConsumer(2))
        self.rabbitmq.register(TestConsumer(3))
        self.rabbitmq.register(TestConsumer(4))

        self.rabbitmq.start()

        publisher.publish("Hallo Welt", 10)
        # self.rabbitmq.stop()
        print("bla")

    def test_rpc(self):
        echo_rpc = TestRPC()
        self.rabbitmq.add_listener(echo_rpc)

        self.rabbitmq.add_listener(TestConsumer(1))

        self.rabbitmq.connect()

        message = echo_rpc.echo("Hallo RPC Welt")
        # self.rabbitmq.stop()
        print("bla")

    def test_connect_proto(self):
        publisher = TestProtoPublisher()
        self.rabbitmq.add_publisher(publisher)

        self.rabbitmq.add_listener(TestProtoConsumer(1))
        self.rabbitmq.add_listener(TestProtoConsumer(2))
        self.rabbitmq.add_listener(TestProtoConsumer(3))
        self.rabbitmq.add_listener(TestProtoConsumer(4))

        self.rabbitmq.connect()

        # time.sleep(1)
        loop = asyncio.get_event_loop()
        loop.run_until_complete(publisher.publish(self._proto_object))
        loop.close()

        print("bla")
