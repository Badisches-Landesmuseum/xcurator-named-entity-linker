import unittest

import pika

from dreipc_message_header import DreiPCMessageHeader
from proto.asset.objectdetection import *
from test_implementation.example import TestConsumer
from util.channel_stub import ChannelStub
from util.rabbit_util import RabbitTestUtil


class TestExampleConsumer(unittest.TestCase):
    # backpressure_detection=t = Flow Control publisher cannot send messages to fast
    AMQP_URL = "amqp://user:password@localhost:5672/%2F"
    consumer = TestConsumer(AMQP_URL)

    def setUp(self) -> None:
        self.messages_recieved = []
        self.consumer._channel = ChannelStub()

    def test_init(self):
        consumer = TestConsumer(self.AMQP_URL)

        self.assertIsNotNone(consumer)

    def test_send_message(self):
        self.consumer.add_typed_on_message_callback(Yolo4DetectionActionProto, self.on_message)

        data_bytes = self.generate_dummy_data()
        self._send_message(data_bytes)

        self.assertEqual(1, len(self.messages_recieved))

    def test_send_message_and_reply(self):
        self.consumer.add_typed_on_message_callback(Yolo4DetectionActionProto, self.on_message)

        data_bytes = self.generate_dummy_data()
        self._send_message(data_bytes)

        self.assertEqual(1, len(self.messages_recieved))

    # HELPER FUNCTIONS
    def on_message(self, body: Yolo4DetectionActionProto, properties):
        self.messages_recieved.append((body, properties))

        return body

    def generate_dummy_data(self) -> bytes:
        proto_data = Yolo4DetectionActionProto('https://example.com/image.jpg')
        return RabbitTestUtil.proto_to_byte(proto_data)

    def _send_message(self, body):
        channel_stub = ChannelStub()
        deliver_tag = type("", (), dict(delivery_tag=1))()

        properties = pika.BasicProperties(content_type='application/protobuf',
                                          headers={DreiPCMessageHeader.MESSAGE_TYPE: 'YOLO4DETECTIONACTIONPROTO'})

        self.consumer._on_message(channel_stub, deliver_tag, properties, body)
