from asyncio.transports import BaseTransport

import pika.channel
from grpclib.protocol import Connection
from h2.connection import H2Connection


class ChannelStub(pika.channel.Channel):

    def __init__(self):
        super().__init__(ConnectionStub(), 0, self.stub_on_open_callback)
        print("Init Stub Channel")

    def stub_on_open_callback(self):
        pass

    def basic_ack(self, delivery_tag=0, multiple=False):
        pass


class ConnectionStub(Connection):
    callbacks = []

    def __init__(self):
        super().__init__(H2Connection(), BaseTransport(), loop=None)
