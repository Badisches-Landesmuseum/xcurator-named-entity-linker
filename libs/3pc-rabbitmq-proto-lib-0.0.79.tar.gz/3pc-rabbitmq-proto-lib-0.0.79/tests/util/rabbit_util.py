from proto_consumer import ProtoConsumer


class RabbitTestUtil(ProtoConsumer):

    @staticmethod
    def proto_to_byte(data) -> bytes:
        return ProtoConsumer.write_delimited(proto_data=data)

    @staticmethod
    def byte_to_proto(data_bytes: bytes, proto_class):
        return ProtoConsumer.read_delimited(data_bytes, proto_class)
