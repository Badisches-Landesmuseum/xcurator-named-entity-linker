from proto.asset.objectdetection import Yolo4DetectionActionProto
from proto_consumer import ProtoConsumer


class TestConsumer(ProtoConsumer):

    # EXCHANGE = 'message'
    # EXCHANGE_TYPE = 'topic'
    # QUEUE = 'text'
    # ROUTING_KEY = 'example.text'

    def __init__(self, amqp_url):
        super().__init__(amqp_url)
        self.add_typed_on_message_callback(Yolo4DetectionActionProto, self.listen)
        self.messages_recieved = []

    def listen(self, body):
        self.messages_recieved.append(body)
